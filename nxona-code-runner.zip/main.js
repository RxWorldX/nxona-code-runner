import { auth } from './auth.js';

let editor = CodeMirror(document.getElementById("editor"), {
  lineNumbers: true,
  mode: "javascript",
  theme: "default"
});

function detectLang(filename) {
  if (filename.endsWith(".js")) return "javascript";
  if (filename.endsWith(".html")) return "htmlmixed";
  if (filename.endsWith(".py")) return "python";
  return "javascript";
}

window.addTab = function () {
  alert("Tab added (demo)");
};

window.saveCode = function () {
  const content = editor.getValue();
  localStorage.setItem("nxona-code", content);
  alert("Code saved locally.");
};

window.downloadCode = function () {
  const blob = new Blob([editor.getValue()], { type: "text/plain" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = document.getElementById("filename").value || "code.js";
  a.click();
};

window.clearCode = function () {
  editor.setValue("");
};

window.copyCode = function () {
  navigator.clipboard.writeText(editor.getValue()).then(() => alert("Copied!"));
};

window.toggleTheme = function () {
  const current = editor.getOption("theme");
  const next = current === "default" ? "material-darker" : "default";
  editor.setOption("theme", next);
};

window.runCode = function () {
  const lang = detectLang(document.getElementById("filename").value);
  const output = document.getElementById("output");
  const code = editor.getValue();

  if (lang === "htmlmixed") {
    output.innerHTML = code;
  } else if (lang === "javascript") {
    try {
      output.innerText = eval(code);
    } catch (e) {
      output.innerText = "Error: " + e.message;
    }
  } else if (lang === "python") {
    output.innerText = "Python execution not supported yet.";
  } else {
    output.innerText = "Unsupported file type.";
  }
};